package com.bie.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bie.dao.UserDao;
import com.bie.dao.impl.UserDaoImpl;
import com.bie.po.User;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;

	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
	            throws ServletException, IOException {
	        this.doPost(request, response);
	    }

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	            throws ServletException, IOException {
	        User user=new User();
	        //��ȡlogin.jspҳ���ύ���˺ź�����
	        String name=request.getParameter("name");
	       
	        //��������
	        System.out.println(name);
	        //��ȡlogin.jspҳ���ύ���˺ź��������õ�ʵ����User��
	        user.setName(name);
	        //user.setPassword(password);
	        
	        //�������ݽ�����
	        UserDao dao=new UserDaoImpl();
	        User us=dao.Query(user);
	        //���Է��ص�ֵ
	        System.out.println(us);
	        if(us!=null){
	        	System.out.println("��ѯ�ɹ�");
	        	response.sendRedirect("E:\\javaAPP\\web\\WebContent\\result.jsp");
	        }else{
	        	System.out.println("��ѯʧ��");
	        }
	        
	       // request.getRequestDispatcher("info.jsp").forward(request, response);
	    }
}
