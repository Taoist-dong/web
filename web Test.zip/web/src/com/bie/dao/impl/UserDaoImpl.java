package com.bie.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bie.dao.UserDao;
import com.bie.po.User;
import com.bie.utils.BaseDao;


public class UserDaoImpl implements UserDao{

    @Override
    public User login(User user) {
        Connection con=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        try {
            con=BaseDao.getCon();//1:��ȡ���ݿ������
            //2:��дsql���
            String sql="select * from logindate where name=? and password=?";
            ps=con.prepareStatement(sql);//3��Ԥ����
            //4������ֵ
            ps.setString(1, user.getName());
            ps.setString(2, user.getPassword());
            rs=ps.executeQuery();//5:ִ��sql���
            User users=null;
            if(rs.next()){
                users=new User();
                //�����ݿ��л�ȡֵ���õ�ʵ�����setter������
                users.setId(rs.getInt("id"));
                users.setName(rs.getString("name"));
                users.setPassword(rs.getString("password"));
                users.setEmail(rs.getString("email"));
                users.setPhone(rs.getString("phone"));
                
                return user;
            }else{
                return null;
            }
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    /***
     * ����ķ�������ע��
     */
    @Override
    public boolean register(User user) {
        String sql="insert into logindate values(?,?,?,?,?) ";
        List<Object> list=new ArrayList<Object>();
        list.add(user.getName());
        list.add(user.getPassword());
        list.add(user.getId());
        list.add(user.getEmail());
        list.add(user.getPhone());
        String sql2="insert into userinfo values(?,?,?) ";
        List<Object> list2=new ArrayList<Object>();
        list2.add(user.getName());
        list2.add(user.getEmail());
        list2.add(user.getPhone());
        boolean flag=BaseDao.addUpdateDelete(sql,list.toArray());
        boolean flag2=BaseDao.addUpdateDelete(sql2,list2.toArray());
        if(flag&&flag2){
            return true;
        }else{
            return false;
        }
    }
    /*
     * ��ѯ
     * */
    public User Query(User user) {
        Connection con=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        try {
            con=BaseDao.getCon();//1:��ȡ���ݿ������
            //2:��дsql���
            String sql="select * from logindate where name=? ";
            ps=con.prepareStatement(sql);//3��Ԥ����
            //4������ֵ
            ps.setString(1, user.getName());
            //ps.setString(2, user.getPassword());
            rs=ps.executeQuery();//5:ִ��sql���
            User users=null;
            if(rs.next()){
                users=new User();
                //�����ݿ��л�ȡֵ���õ�ʵ�����setter������
                users.setId(rs.getInt("id"));
                users.setName(rs.getString("name"));
                users.setPassword(rs.getString("password"));
                users.setEmail(rs.getString("email"));
                users.setPhone(rs.getString("phone"));
                
                return user;
            }else{
                return null;
            }
            
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
   /*public void delete(User user) throws SQLException {  
    	Connection con = null;  
    	PreparedStatement ps = null;  
    	String sql = "delete from logindate where name in (?)";//����nameɾ��  
    	try{  
    		con=BaseDao.getCon();  
    	    ps = con.prepareStatement(sql);  
    	    ps.setInt(1, user.getId());  
    	    ps.execute();  
    	    }catch(SQLException e){  
    	         e.printStackTrace();  
    	    throw new SQLException("ɾ��ʧ��");  
    	    }  
}
    public boolean update(User user) {
        String sql="update logindate  password=? where name=? ";
        List<Object> list=new ArrayList<Object>();
        list.add(user.getPassword());
        list.add(user.getName());
        boolean flag=BaseDao.addUpdateDelete(sql,list.toArray());

        if(flag){
            return true;
        }else{
            return false;
        }
    }*/
}
